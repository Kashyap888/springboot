package com.PES2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Pes2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
